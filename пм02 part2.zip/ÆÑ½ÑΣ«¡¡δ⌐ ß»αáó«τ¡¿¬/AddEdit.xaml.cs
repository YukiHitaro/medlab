﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Телефонный_справочник
{
    /// <summary>
    /// Логика взаимодействия для AddEdit.xaml
    /// </summary>
    public partial class AddEdit : Window
    {
        public AddEdit()
        {
            InitializeComponent();
        }

        public int id;
        public int cont
        {
            get { return id; }
            set { id = value; }

        }
        public Контакт контакт;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
			 
            try
            {
                if (контакт != null)
                {
                    using (var db = new user11Entities3())
                    {
                        Контакт contact = db.Контакт.Find(cont);
                        Группа_контактов group = db.Группа_контактов.Find(contact.ID_Группа_контактов);

                        Lastname.Text = contact.Фамилия;
                        Namecont.Text = contact.Имя;
                        nameTB.Text = contact.Отчество;
                        number.Text = contact.Номер_телефона;
                        datebirth1.Text = contact.Дата_Рождения.ToString();
                        email.Text = contact.E_mail;
                        Company.Text = contact.Компания.ToString();
                        WorkTb.Text = contact.Должность;
                    }
                }
                else
                {
                    // Если контакт не найден,  то присваиваем ID = 0 
                    // (это значение ID будет использоваться для добавления нового контакта)
                    контакт = new Контакт { ID = 0 };
                }
            }
            catch
            {
                MessageBox.Show("Ошибка БД");
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new user11Entities3())
                {
                    
                    if (контакт.ID == 0)
                    {
                        
                        int maxId = db.Контакт.Max(c => c.ID);
                        контакт.ID = maxId + 1;

                        db.Контакт.Add(контакт);
                    }
                    else
                    {
                       
                        db.Entry(контакт).State = System.Data.Entity.EntityState.Modified;
                    }

                    db.SaveChanges();
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message);
            }

        }
    }
}
