﻿using System;
using System.Linq;
using System.Numerics;

namespace SimplexSolver
{
    public class SimplexSolver
    {
        public enum ConstraintType
        {
            LessThanOrEqual = 0, 
            GreaterThanOrEqual = 1, 
            Equal = 2 
        }
        public double[] Solve(double[,] coefficients, double[] constraints, int[] inequalityTypes)
        {
            for (int i = 0; i < inequalityTypes.Length; i++)
            {
                if (inequalityTypes[i] == 1) // >=
                {
                    for (int j = 0; j < coefficients.GetLength(1); j++)
                    {
                        coefficients[i, j] *= -1;
                    }
                    constraints[i] *= -1;
                }
            }
            int artificialVariablesCount = inequalityTypes.Count(t => t == 1);
            double[,] tableau = new double[constraints.Length + 1, coefficients.GetLength(1) + artificialVariablesCount + 1];

            for (int i = 0; i < constraints.Length; i++)
            {
                for (int j = 0; j < coefficients.GetLength(1); j++)
                {
                    tableau[i, j] = coefficients[i, j];
                }
                tableau[i, coefficients.GetLength(1) + i] = (inequalityTypes[i] == 1) ? 1 : 0; // Добавить искусственные переменные
                tableau[i, tableau.GetLength(1) - 1] = constraints[i];
            }

            for (int j = 0; j < coefficients.GetLength(1); j++)
            {
                tableau[tableau.GetLength(0) - 1, j] = -coefficients[coefficients.GetLength(0) - 1, j];
            }

            while (true)
            {
                int pivotColumn = FindPivotColumn(tableau);
                if (pivotColumn == -1)
                {
                    break;
                }
                int pivotRow = FindPivotRow(tableau, pivotColumn);
                if (pivotRow == -1)
                {
                    throw new Exception("Задача не имеет ограничений");
                }
                Pivot(tableau, pivotRow, pivotColumn);
            }

            double[] solution = new double[coefficients.GetLength(1)];
            for (int i = 0; i < coefficients.GetLength(1); i++)
            {
                solution[i] = tableau[tableau.GetLength(0) - 1, i];
            }

            return solution;
        }

        private int FindPivotColumn(double[,] tableau)
        {
            int pivotColumn = -1;
            for (int j = 0; j < tableau.GetLength(1) - 1; j++)
            {
                if (tableau[tableau.GetLength(0) - 1, j] < 0)
                {
                    pivotColumn = j;
                    break;
                }
            }
            return pivotColumn;
        }

        private int FindPivotRow(double[,] tableau, int pivotColumn)
        {
            int pivotRow = -1;
            double minRatio = double.MaxValue;
            for (int i = 0; i < tableau.GetLength(0) - 1; i++)
            {
                if (tableau[i, pivotColumn] > 0)
                {
                    double ratio = tableau[i, tableau.GetLength(1) - 1] / tableau[i, pivotColumn];
                    if (ratio < minRatio)
                    {
                        minRatio = ratio;
                        pivotRow = i;
                    }
                }
            }
            return pivotRow;
        }

        private void Pivot(double[,] tableau, int pivotRow, int pivotColumn)
        {
            for (int j = 0; j < tableau.GetLength(1); j++)
            {
                tableau[pivotRow, j] /= tableau[pivotRow, pivotColumn];
            }

            for (int i = 0; i < tableau.GetLength(0); i++)
            {
                if (i != pivotRow)
                {
                    double factor = tableau[i, pivotColumn];
                    for (int j = 0; j < tableau.GetLength(1); j++)
                    {
                        tableau[i, j] -= factor * tableau[pivotRow, j];
                    }
                }
            }
        }
    }
}