﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimplexSolver
{
    public enum ConstraintType
    {
        LessThanOrEqual = 0, 
        GreaterThanOrEqual = 1, 
        Equal = 2 
    }
    public class Constraint
    {
        public double Variable1 { get; set; }
        public double Variable2 { get; set; }
        public double Constant { get; set; }
        public ConstraintType Type { get; set; }
    }
}
