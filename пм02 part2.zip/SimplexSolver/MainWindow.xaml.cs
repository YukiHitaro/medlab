﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.ComponentModel;
namespace SimplexSolver
{ 

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ConstraintsDataGrid.ItemsSource = new List<ConstraintData>();
            ConstraintsDataGrid.Items.Add(new ConstraintData()); 
            DataGridComboBoxColumn constraintTypeColumn = (DataGridComboBoxColumn)this.FindResource("ConstraintTypeComboBoxColumn");
            ConstraintsDataGrid.Columns.Add(constraintTypeColumn);
        }
        public static IEnumerable<ConstraintType> GetValues(Type enumType)
        {
            return Enum.GetValues(enumType).Cast<ConstraintType>();
        }
        private void SolveButtonClick(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(ObjectiveFunctionTextBox.Text))
                {
                    MessageBox.Show("Пожалуйста, введите целевую функцию.");
                    return;
                }

                if (ConstraintsDataGrid.Items.Count == 0)
                {
                    MessageBox.Show("Пожалуйста, введите хотя бы одно ограничение.");
                    return;
                }
                string[] objectiveFunctionCoefficients = ObjectiveFunctionTextBox.Text.Split(' ').Where(s => !string.IsNullOrEmpty(s)).ToArray();
                if (objectiveFunctionCoefficients.Length != 3)
                {
                    MessageBox.Show("Неправильный формат целевой функции.");
                    return;
                }

                double[] objectiveCoefficients = new double[2];
                if (!double.TryParse(objectiveFunctionCoefficients[1], out objectiveCoefficients[0]) ||
                    !double.TryParse(objectiveFunctionCoefficients[2], out objectiveCoefficients[1]))
                {
                    MessageBox.Show("Неправильный формат коэффициентов целевой функции.");
                    return;
                }

                List<ConstraintData> constraintDataList = ConstraintsDataGrid.Items.Cast<ConstraintData>().ToList();
                double[,] constraintsCoefficients = new double[constraintDataList.Count, 3];
                int[] inequalityTypes = new int[constraintDataList.Count];
                for (int i = 0; i < constraintDataList.Count; i++)
                {
                    constraintsCoefficients[i, 0] = constraintDataList[i].Variable1;
                    constraintsCoefficients[i, 1] = constraintDataList[i].Variable2;
                    constraintsCoefficients[i, 2] = constraintDataList[i].Constant;
                    inequalityTypes[i] = (int)constraintDataList[i].Type;
                }
                SimplexSolver solver = new SimplexSolver();
                double[] solution = solver.Solve(constraintsCoefficients, new double[constraintDataList.Count], inequalityTypes);
                ResultsListBox.Items.Clear();
                ResultsListBox.Items.Add($"x1 = {solution[0]}");
                ResultsListBox.Items.Add($"x2 = {solution[1]}");
                ResultsListBox.Items.Add($"F(x) = {objectiveCoefficients[0] * solution[0] + objectiveCoefficients[1] * solution[1]}");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }

    public class ConstraintData : INotifyPropertyChanged
    {
        private double _variable1;
        private double _variable2;
        private double _constant;
        private ConstraintType _type;

        public double Variable1
        {
            get { return _variable1; }
            set { _variable1 = value; OnPropertyChanged("Variable1"); }
        }

        public double Variable2
        {
            get { return _variable2; }
            set { _variable2 = value; OnPropertyChanged("Variable2"); }
        }

        public double Constant
        {
            get { return _constant; }
            set { _constant = value; OnPropertyChanged("Constant"); }
        }

        public ConstraintType Type
        {
            get { return _type; }
            set { _type = value; OnPropertyChanged("Type"); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}