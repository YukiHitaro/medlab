﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedLab
{
    public partial class RegWindow : Window
    {
        public RegWindow()
        {
            InitializeComponent();
        }
        private void MoveForm(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void ExitForm(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }
        private void RegBtn(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(NameTextBox.Text) ||
                string.IsNullOrEmpty(LoginTextBox.Text) ||
                string.IsNullOrEmpty(PasswordBox.Password) ||
                string.IsNullOrEmpty(ServicesTextBox.Text) ||
                TypeComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Пожалуйста, заполните все необходимые поля.");
                return;
            }

            users newUser = new users
            {
                name = NameTextBox.Text,
                login = LoginTextBox.Text,
                password = PasswordBox.Password,
                ip = "",
                lastenter = DateTime.Now,
                services = ServicesTextBox.Text,
                type = TypeComboBox.SelectedIndex + 1
            };
            try
            {
                using (var db = new MedlabEntities())
                {
                    if (db.users.Any(u => u.login == newUser.login))
                    {
                        MessageBox.Show("Имя пользователя уже занято. Пожалуйста, выберите другое имя пользователя.");
                        return;
                    }
                    db.users.Add(newUser);
                    db.SaveChanges();

                    MessageBox.Show("Регистрация прошла успешно!");
                    NameTextBox.Text = "";
                    LoginTextBox.Text = "";
                    PasswordBox.Password = "";
                    ServicesTextBox.Text = "";
                    TypeComboBox.SelectedIndex = -1;
                    MainWindow MW = new MainWindow();
                    MW.Show();
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при регистрации: " + ex.Message);
            }
        }
    }
}
