﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Drawing;
using System.IO;

namespace MedLab
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ExitForm(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        private void MoveForm(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        public int loginAttempts = 3;
        private BitmapImage currentCaptchaImage;
        private string currentCaptchaText;

        private void BtnStartWindw(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new MedlabEntities())
                {
                    if (CapTB1.Visibility == Visibility.Visible)
                    {
                        if (CapTB.Text == currentCaptchaText)
                        {
                            MessageBox.Show("Капча введена верно!");
                            CapTB1.Visibility = Visibility.Hidden;
                            CapTB.Visibility = Visibility.Hidden;
                            CapTB.Text = "";
                            loginAttempts = 3;
                        }
                        else
                        {
                            MessageBox.Show("Капча введена неверно");
                            loginAttempts--;
                            MessageBox.Show("Попыток осталось: " + loginAttempts.ToString());

                            if (loginAttempts == 0)
                            {
                                Timer timerWindow = new Timer();
                                timerWindow.ShowDialog();

                                loginAttempts = 3;
                            }

                            GenerateNewCaptcha();
                            CapTB.Text = "";
                            return;
                        }
                    }

                    var user = db.users.FirstOrDefault(s => s.login == LogTB.Text && s.password == PasTB.Password);

                    if (user != null)
                    {
                        MessageBox.Show("Авторизация прошла успешно");

                        switch (user.type)
                        {
                            case 1:
                                StartWindow startWindow = new StartWindow();
                                startWindow.Show();
                                startWindow.NameUser.Content = user.name;
                                this.Close();
                                break;
                            case 2:
                                LabWindow labwindow = new LabWindow();
                                labwindow.Show();
                                labwindow.NameUser.Content = user.name;
                                this.Close();
                                break;
                            case 3:
                                BuhgWindow buhgwindow = new BuhgWindow();
                                buhgwindow.Show();
                                buhgwindow.NameUser.Content = user.name;
                                this.Close();
                                break;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Логин или пароль не верны");


                        if (CapTB1.Visibility != Visibility.Visible)
                        {
                            loginAttempts--;
                            MessageBox.Show("Попыток осталось: " + loginAttempts.ToString());
                        }

                        if (loginAttempts == 0)
                        {
                            MessageBox.Show("Введите капчу");
                            currentCaptchaText = captcha();
                            CapTB1.Visibility = Visibility.Visible;
                            CapTB.Visibility = Visibility.Visible;
                            loginAttempts = 3;
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("Ошибка подключения к БД");
            }
        }
        private void GenerateNewCaptcha()
        {

            currentCaptchaText = GenerateCaptchaText(6);


            currentCaptchaImage = CreateCaptchaImage(currentCaptchaText, 150, 50);
            CapTB1.Source = currentCaptchaImage;
        }
        private BitmapImage CreateCaptchaImage(string captchaText, int width, int height)
        {
            Bitmap bmp = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(System.Drawing.Color.Green);
                g.DrawString(captchaText, new Font("Arial", 20), System.Drawing.Brushes.Black, new PointF(10, 10));
            }

            using (MemoryStream memory = new MemoryStream())
            {
                bmp.Save(memory, System.Drawing.Imaging.ImageFormat.Png);
                memory.Position = 0;
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = memory;
                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                bitmapImage.EndInit();
                return bitmapImage;
            }
        }

        private string GenerateCaptchaText(int length)
        {
            Random rnd = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[rnd.Next(s.Length)]).ToArray());
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            RegWindow RW = new RegWindow();
            RW.Show();
            this.Close();
        }

        public string captcha()
        {
            Random rnd = new Random();
            char[] z = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                         'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
                         'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                         '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '_', '+', '=' };

            string captcha = "";
            for (int i = 0; i < 12; i++)
            {
                int j = rnd.Next(0, z.Length);
                captcha += z[j];
            }
            return captcha;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            CapTB1.Visibility = Visibility.Hidden;
            CapTB.Visibility = Visibility.Hidden;
            GenerateNewCaptcha();
        }
    }
}